PALLET_ID = 'fusion101'
PALLET_NAME = 'Fusion 101'
DEBUG = False
if DEBUG:
    PALLET_URL = 'http://localhost:8080'
else:
    PALLET_URL = './web/dist/index.html'
